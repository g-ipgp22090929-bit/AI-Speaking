# AI Speaking Adventure — Year 3 (SK)

A beginner-friendly, single-page prototype for a Year 3 English speaking game. It includes three short missions:
- The Food Market
- At School
- At the Park

## Important note
This prototype uses the browser's Web Speech API for speech recognition and speech synthesis, plus simple keyword matching. **It does not currently use a generative AI model**, so describe it as a speech-enabled digital game unless you later add an AI service. Keyword matching is only a prototype: it does not reliably judge grammar, pronunciation, or meaning, and it may accept an answer that contains a keyword without fully answering the question.

## Run locally
1. Download `index.html`.
2. Open it in a recent version of Microsoft Edge or Google Chrome.
3. Allow microphone access when prompted.
4. If speech recognition is unavailable, the game provides a text fallback for testing.

Browser support varies. Microphone features generally work best when the site is served over HTTPS, such as GitHub Pages. Always test on the actual device/browser before classroom use.

## Publish with GitHub Pages
1. Sign in to GitHub and create a new repository, e.g. `year3-speaking-adventure`.
2. Upload `index.html` to the root of the repository.
3. Open **Settings → Pages**.
4. Under the build/deployment source, choose **Deploy from a branch**.
5. Choose the `main` branch and `/ (root)`, then save.
6. Wait for the published URL shown in the Pages section.
7. Open the URL in Chrome/Edge, allow microphone access, and test each mission.

## Teaching and privacy notes
- Try the prototype with a small number of users before classroom use.
- Do not collect pupils' names or personal information.
- Tell pupils/guardians that browser speech recognition may process audio using the browser's speech service; check the browser/provider privacy terms before using it with children.
- Provide a non-microphone alternative and do not penalise pupils when speech recognition mishears them.
- Align the final activities with the specific Year 3 SK DSKP standards selected in your lesson plan. Verify exact standard wording and page numbers against the official DSKP before submitting academic work.
